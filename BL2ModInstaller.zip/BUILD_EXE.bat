@echo off
python -m pip install pyinstaller
python -m PyInstaller --onefile --noconsole --name BL2ModInstaller BL2ModInstaller.py
copy dist\BL2ModInstaller.exe .
echo Gotovo: BL2ModInstaller.exe
pause
