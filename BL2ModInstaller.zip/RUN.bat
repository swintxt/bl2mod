@echo off
python BL2ModInstaller.py
pause
